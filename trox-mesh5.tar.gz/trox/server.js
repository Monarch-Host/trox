// server.js — Trox: web chat + public API + secret owner panel for the Mesh 5 model
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const store = require('./db');

// ---------- config (see .env.example) ----------
try { // tiny .env loader, no extra dependency
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (_) {}

const PORT = parseInt(process.env.PORT, 10) || 6969;
const HOST = process.env.HOST || '127.0.0.1'; // Cloudflare Tunnel connects locally
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
const OWNER_PATH = (process.env.OWNER_PATH || '').replace(/^\/+|\/+$/g, '');
const OWNER_PASSWORD = process.env.OWNER_PASSWORD || '';
const MAX_CONCURRENT = parseInt(process.env.MAX_CONCURRENT, 10) || 1;
const SECURE_COOKIES = process.env.SECURE_COOKIES !== '0'; // Cloudflare serves HTTPS

if (!OWNER_PATH || OWNER_PATH.length < 8 || !OWNER_PASSWORD || OWNER_PASSWORD.length < 10) {
  console.error('Set OWNER_PATH (8+ chars, secret) and OWNER_PASSWORD (10+ chars) in .env before starting.');
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

// ---------- helpers ----------
const clientIp = (req) => req.headers['cf-connecting-ip'] || req.socket.remoteAddress || 'unknown';

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setCookie(res, name, value, maxAgeSec) {
  res.append('Set-Cookie', `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}${SECURE_COOKIES ? '; Secure' : ''}`);
}
const clearCookie = (res, name) => setCookie(res, name, '', 0);

// sliding-window limiter (in memory)
function makeLimiter() {
  const hits = new Map();
  return function allow(key, max, windowMs) {
    const t = Date.now();
    const arr = (hits.get(key) || []).filter((x) => t - x < windowMs);
    if (arr.length >= max) { hits.set(key, arr); return false; }
    arr.push(t); hits.set(key, arr);
    return true;
  };
}
const limiter = makeLimiter();
setInterval(() => { /* keep map from growing forever */ }, 3600e3).unref();

// simple concurrency gate so a small VPS isn't overwhelmed
let running = 0;
const waiting = [];
function acquire() {
  return new Promise((resolve) => {
    if (running < MAX_CONCURRENT) { running++; resolve(); } else waiting.push(resolve);
  });
}
function release() {
  const next = waiting.shift();
  if (next) next(); else running--;
}

// ---------- model call (Ollama) ----------
async function streamModel(messages, onToken, signal) {
  const cfg = store.allSettings();
  const msgs = cfg.system_prompt.trim()
    ? [{ role: 'system', content: cfg.system_prompt }, ...messages]
    : messages;
  const r = await fetch(`${OLLAMA_URL}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model: cfg.model,
      messages: msgs,
      stream: true,
      options: { temperature: parseFloat(cfg.temperature) || 0.7 },
    }),
    signal,
  });
  if (!r.ok) throw new Error(`Model backend returned ${r.status}`);
  const dec = new TextDecoder();
  let buf = '';
  let full = '';
  for await (const chunk of r.body) {
    buf += dec.decode(chunk, { stream: true });
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (!line) continue;
      let j;
      try { j = JSON.parse(line); } catch { continue; }
      if (j.error) throw new Error(j.error);
      const t = j.message && j.message.content;
      if (t) { full += t; onToken(t); }
    }
  }
  return full;
}

function cleanMessages(arr) {
  if (!Array.isArray(arr) || !arr.length || arr.length > 40) return null;
  const out = [];
  for (const m of arr) {
    if (!m || !['user', 'assistant', 'system'].includes(m.role) || typeof m.content !== 'string') return null;
    if (m.content.length > 8000) return null;
    out.push({ role: m.role, content: m.content });
  }
  return out;
}

// ---------- web auth ----------
const USER_RE = /^[a-zA-Z0-9_]{3,24}$/;

function requireUser(req, res, next) {
  const user = store.getSessionUser(parseCookies(req).trox_session);
  if (!user) return res.status(401).json({ error: 'Not signed in' });
  req.user = user;
  next();
}

app.post('/api/signup', (req, res) => {
  if (!limiter('signup:' + clientIp(req), 5, 3600e3)) return res.status(429).json({ error: 'Too many signups, try later' });
  if (store.getSetting('signups_open') !== '1') return res.status(403).json({ error: 'Signups are closed' });
  const { username, password } = req.body || {};
  if (!USER_RE.test(username || '')) return res.status(400).json({ error: 'Username: 3-24 letters, numbers or _' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 200) return res.status(400).json({ error: 'Password must be 8+ characters' });
  if (store.getUserByName(username)) return res.status(409).json({ error: 'Username taken' });
  const id = store.createUser(username, password);
  setCookie(res, 'trox_session', store.createSession(id), 30 * 86400);
  res.json({ ok: true, username });
});

app.post('/api/login', (req, res) => {
  if (!limiter('login:' + clientIp(req), 10, 15 * 60e3)) return res.status(429).json({ error: 'Too many attempts, wait a bit' });
  const { username, password } = req.body || {};
  const user = typeof username === 'string' ? store.getUserByName(username) : null;
  if (!user || typeof password !== 'string' || !store.verifyPassword(password, user.pass_hash) || user.banned)
    return res.status(401).json({ error: 'Wrong username or password' });
  setCookie(res, 'trox_session', store.createSession(user.id), 30 * 86400);
  res.json({ ok: true, username: user.username });
});

app.post('/api/logout', (req, res) => {
  const t = parseCookies(req).trox_session;
  if (t) store.deleteSession(t);
  clearCookie(res, 'trox_session');
  res.json({ ok: true });
});

app.get('/api/me', requireUser, (req, res) => res.json({ username: req.user.username }));

// ---------- web chats ----------
app.get('/api/chats', requireUser, (req, res) => res.json(store.listChats(req.user.id)));

app.post('/api/chats', requireUser, (req, res) => {
  res.json({ id: store.createChat(req.user.id, 'New chat') });
});

app.get('/api/chats/:id', requireUser, (req, res) => {
  const chat = store.getChat(+req.params.id, req.user.id);
  if (!chat) return res.status(404).json({ error: 'Not found' });
  res.json({ chat, messages: store.getMessages(chat.id) });
});

app.delete('/api/chats/:id', requireUser, (req, res) => {
  store.deleteChat(+req.params.id, req.user.id);
  res.json({ ok: true });
});

app.post('/api/chats/:id/send', requireUser, async (req, res) => {
  const chat = store.getChat(+req.params.id, req.user.id);
  if (!chat) return res.status(404).json({ error: 'Not found' });
  const text = (req.body && typeof req.body.message === 'string' ? req.body.message : '').trim();
  if (!text || text.length > 4000) return res.status(400).json({ error: 'Message must be 1-4000 characters' });
  if (!limiter('web:' + req.user.id, 30, 60e3)) return res.status(429).json({ error: 'Slow down a little' });

  const history = store.getMessages(chat.id, 20).map((m) => ({ role: m.role, content: m.content }));
  store.addMessage(chat.id, 'user', text);
  if (chat.title === 'New chat') store.renameChat(chat.id, text.slice(0, 40));

  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const ac = new AbortController();
  res.on('close', () => ac.abort());
  const t0 = Date.now();
  await acquire();
  let reply = '';
  let ok = 1;
  try {
    reply = await streamModel([...history, { role: 'user', content: text }], (t) => res.write(t), ac.signal);
    if (reply) store.addMessage(chat.id, 'assistant', reply);
  } catch (e) {
    ok = 0;
    if (!ac.signal.aborted) res.write('\n\n[Mesh 5 is unavailable right now. Please try again shortly.]');
    console.error('chat error:', e.message);
  } finally {
    release();
    store.logUsage({ userId: req.user.id, source: 'web', promptChars: text.length, replyChars: reply.length, ms: Date.now() - t0, ok });
    res.end();
  }
});

// ---------- API keys (user-managed) ----------
app.get('/api/keys', requireUser, (req, res) => res.json(store.listKeys(req.user.id)));

app.post('/api/keys', requireUser, (req, res) => {
  const max = parseInt(store.getSetting('max_keys_per_user'), 10) || 5;
  if (store.countActiveKeys(req.user.id) >= max) return res.status(400).json({ error: `Limit of ${max} active keys reached` });
  const label = String((req.body && req.body.label) || 'key').slice(0, 40);
  res.json(store.createKey(req.user.id, label)); // raw key is shown once
});

app.delete('/api/keys/:id', requireUser, (req, res) => {
  store.revokeKey(+req.params.id, req.user.id);
  res.json({ ok: true });
});

// ---------- public API: POST /v1/chat ----------
app.post('/v1/chat', async (req, res) => {
  const m = (req.headers.authorization || '').match(/^Bearer\s+(\S+)$/i);
  const key = m && store.getKey(m[1]);
  if (!key || key.banned) return res.status(401).json({ error: 'Invalid API key' });
  if (!limiter('key:' + key.id, key.rate_per_min, 60e3))
    return res.status(429).json({ error: `Rate limit: ${key.rate_per_min} requests/minute` });

  const messages = cleanMessages(req.body && req.body.messages);
  if (!messages) return res.status(400).json({ error: 'Send {"messages":[{"role":"user","content":"..."}]} (max 40 messages, 8000 chars each)' });
  const stream = !!(req.body && req.body.stream);
  store.touchKey(key.id);

  const promptChars = messages.reduce((n, x) => n + x.content.length, 0);
  const ac = new AbortController();
  res.on('close', () => ac.abort());
  const t0 = Date.now();
  await acquire();
  let reply = '';
  let ok = 1;
  try {
    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-store');
      res.setHeader('X-Accel-Buffering', 'no');
      res.flushHeaders();
      reply = await streamModel(messages, (t) => res.write(`data: ${JSON.stringify({ delta: t })}\n\n`), ac.signal);
      res.write('data: [DONE]\n\n');
      res.end();
    } else {
      reply = await streamModel(messages, () => {}, ac.signal);
      res.json({ model: 'mesh-5', message: { role: 'assistant', content: reply } });
    }
  } catch (e) {
    ok = 0;
    console.error('api error:', e.message);
    if (!res.headersSent) res.status(502).json({ error: 'Model unavailable' });
    else if (!res.writableEnded) { res.write(`data: ${JSON.stringify({ error: 'Model unavailable' })}\n\n`); res.end(); }
  } finally {
    release();
    store.logUsage({ userId: key.user_id, keyId: key.id, source: 'api', promptChars, replyChars: reply.length, ms: Date.now() - t0, ok });
  }
});

app.get('/v1/health', (req, res) => res.json({ ok: true, model: 'mesh-5' }));

// ---------- secret owner panel ----------
const ownerSessions = new Map(); // token -> expiry (cleared on restart)
const ownerBase = '/' + OWNER_PATH;

function safeEqual(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}
function requireOwner(req, res, next) {
  const t = parseCookies(req).trox_owner;
  const exp = t && ownerSessions.get(t);
  if (!exp || exp < Date.now()) return res.status(401).json({ error: 'Owner login required' });
  next();
}

app.get(ownerBase, (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.sendFile(path.join(__dirname, 'views', 'owner.html'));
});

app.post(ownerBase + '/login', (req, res) => {
  if (!limiter('owner:' + clientIp(req), 5, 15 * 60e3)) return res.status(429).json({ error: 'Locked for 15 minutes' });
  if (!safeEqual((req.body && req.body.password) || '', OWNER_PASSWORD)) return res.status(401).json({ error: 'Wrong password' });
  const token = crypto.randomBytes(32).toString('hex');
  ownerSessions.set(token, Date.now() + 12 * 3600e3);
  setCookie(res, 'trox_owner', token, 12 * 3600);
  res.json({ ok: true });
});

app.post(ownerBase + '/logout', (req, res) => {
  ownerSessions.delete(parseCookies(req).trox_owner);
  clearCookie(res, 'trox_owner');
  res.json({ ok: true });
});

app.get(ownerBase + '/api/overview', requireOwner, (req, res) => res.json({
  stats: store.stats(), settings: store.allSettings(), usage: store.recentUsage(50),
}));
app.get(ownerBase + '/api/users', requireOwner, (req, res) => res.json(store.listUsers()));
app.get(ownerBase + '/api/keys', requireOwner, (req, res) => res.json(store.listAllKeys()));

app.post(ownerBase + '/api/users/:id/ban', requireOwner, (req, res) => {
  store.setBanned(+req.params.id, !!(req.body && req.body.banned));
  res.json({ ok: true });
});
app.delete(ownerBase + '/api/users/:id', requireOwner, (req, res) => {
  store.deleteUser(+req.params.id);
  res.json({ ok: true });
});
app.delete(ownerBase + '/api/keys/:id', requireOwner, (req, res) => {
  store.revokeKey(+req.params.id);
  res.json({ ok: true });
});
app.post(ownerBase + '/api/keys/:id/rate', requireOwner, (req, res) => {
  const n = parseInt(req.body && req.body.rate, 10);
  if (!(n >= 1 && n <= 10000)) return res.status(400).json({ error: 'Rate must be 1-10000' });
  store.setKeyRate(+req.params.id, n);
  res.json({ ok: true });
});
app.post(ownerBase + '/api/settings', requireOwner, (req, res) => {
  try {
    for (const [k, v] of Object.entries(req.body || {})) {
      if (typeof v === 'string' && v.length <= 4000) store.setSetting(k, v);
    }
    res.json(store.allSettings());
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// ---------- static site ----------
app.use(express.static(path.join(__dirname, 'public'), { index: 'index.html', maxAge: '1h' }));
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, HOST, () => {
  console.log(`Trox (Mesh 5) listening on http://${HOST}:${PORT}`);
});
