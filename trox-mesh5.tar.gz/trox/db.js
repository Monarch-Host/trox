// db.js — Trox database layer (SQLite). Everything the app stores lives in data/trox.db
const Database = require('better-sqlite3');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'trox.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  banned INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS api_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key_hash TEXT NOT NULL UNIQUE,
  prefix TEXT NOT NULL,
  label TEXT NOT NULL,
  rate_per_min INTEGER NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0,
  requests INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  last_used INTEGER
);
CREATE TABLE IF NOT EXISTS usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  key_id INTEGER,
  source TEXT NOT NULL,
  prompt_chars INTEGER NOT NULL DEFAULT 0,
  reply_chars INTEGER NOT NULL DEFAULT 0,
  ms INTEGER NOT NULL DEFAULT 0,
  ok INTEGER NOT NULL DEFAULT 1,
  ts INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_chats_user ON chats(user_id);
CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage(ts);
`);

const now = () => Date.now();
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

// ---------- passwords ----------
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(pw, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(pw, stored) {
  const [salt, hash] = String(stored).split(':');
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(pw, salt, 64);
  const real = Buffer.from(hash, 'hex');
  return real.length === test.length && crypto.timingSafeEqual(real, test);
}

// ---------- settings ----------
const DEFAULT_SETTINGS = {
  model: 'mesh5',
  system_prompt: '',
  temperature: '0.7',
  signups_open: '1',
  default_rate_per_min: '20',
  max_keys_per_user: '5',
};
function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : DEFAULT_SETTINGS[key];
}
function setSetting(key, value) {
  if (!(key in DEFAULT_SETTINGS)) throw new Error('Unknown setting');
  db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
    .run(key, String(value));
}
function allSettings() {
  const out = {};
  for (const k of Object.keys(DEFAULT_SETTINGS)) out[k] = getSetting(k);
  return out;
}

// ---------- users & sessions ----------
function createUser(username, password) {
  const info = db.prepare('INSERT INTO users(username,pass_hash,created_at) VALUES(?,?,?)')
    .run(username, hashPassword(password), now());
  return info.lastInsertRowid;
}
const getUserByName = (u) => db.prepare('SELECT * FROM users WHERE username = ?').get(u);
const getUserById = (id) => db.prepare('SELECT * FROM users WHERE id = ?').get(id);
const listUsers = () => db.prepare(`
  SELECT u.id, u.username, u.banned, u.created_at,
    (SELECT COUNT(*) FROM chats c WHERE c.user_id = u.id) AS chats,
    (SELECT COUNT(*) FROM api_keys k WHERE k.user_id = u.id AND k.revoked = 0) AS keys
  FROM users u ORDER BY u.id DESC`).all();
function setBanned(id, banned) {
  db.prepare('UPDATE users SET banned = ? WHERE id = ?').run(banned ? 1 : 0, id);
  if (banned) db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
}
const deleteUser = (id) => db.prepare('DELETE FROM users WHERE id = ?').run(id);

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash,user_id,created_at) VALUES(?,?,?)').run(sha256(token), userId, now());
  return token;
}
const SESSION_TTL = 30 * 24 * 3600 * 1000;
function getSessionUser(token) {
  if (!token) return null;
  const row = db.prepare(`SELECT u.*, s.created_at AS s_created FROM sessions s
    JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(sha256(token));
  if (!row) return null;
  if (now() - row.s_created > SESSION_TTL) { deleteSession(token); return null; }
  if (row.banned) return null;
  return row;
}
const deleteSession = (token) => db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));

// ---------- chats ----------
const createChat = (userId, title) =>
  db.prepare('INSERT INTO chats(user_id,title,created_at) VALUES(?,?,?)').run(userId, title || 'New chat', now()).lastInsertRowid;
const listChats = (userId) => db.prepare('SELECT id,title,created_at FROM chats WHERE user_id = ? ORDER BY id DESC').all(userId);
const getChat = (id, userId) => db.prepare('SELECT * FROM chats WHERE id = ? AND user_id = ?').get(id, userId);
const renameChat = (id, title) => db.prepare('UPDATE chats SET title = ? WHERE id = ?').run(title, id);
const deleteChat = (id, userId) => db.prepare('DELETE FROM chats WHERE id = ? AND user_id = ?').run(id, userId);
const addMessage = (chatId, role, content) =>
  db.prepare('INSERT INTO messages(chat_id,role,content,created_at) VALUES(?,?,?,?)').run(chatId, role, content, now());
const getMessages = (chatId, limit = 1000) =>
  db.prepare('SELECT role,content,created_at FROM (SELECT id,role,content,created_at FROM messages WHERE chat_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id').all(chatId, limit);

// ---------- API keys ----------
function createKey(userId, label) {
  const raw = 'mesh5_' + crypto.randomBytes(24).toString('hex');
  const info = db.prepare(`INSERT INTO api_keys(user_id,key_hash,prefix,label,rate_per_min,created_at)
    VALUES(?,?,?,?,?,?)`).run(userId, sha256(raw), raw.slice(0, 12), label || 'key', parseInt(getSetting('default_rate_per_min'), 10) || 20, now());
  return { id: info.lastInsertRowid, key: raw };
}
function getKey(raw) {
  return db.prepare(`SELECT k.*, u.username, u.banned FROM api_keys k JOIN users u ON u.id = k.user_id
    WHERE k.key_hash = ? AND k.revoked = 0`).get(sha256(raw));
}
const touchKey = (id) => db.prepare('UPDATE api_keys SET requests = requests + 1, last_used = ? WHERE id = ?').run(now(), id);
const listKeys = (userId) => db.prepare(`SELECT id,prefix,label,rate_per_min,revoked,requests,created_at,last_used
  FROM api_keys WHERE user_id = ? ORDER BY id DESC`).all(userId);
const countActiveKeys = (userId) => db.prepare('SELECT COUNT(*) AS n FROM api_keys WHERE user_id = ? AND revoked = 0').get(userId).n;
const listAllKeys = () => db.prepare(`SELECT k.id,k.prefix,k.label,k.rate_per_min,k.revoked,k.requests,k.created_at,k.last_used,u.username
  FROM api_keys k JOIN users u ON u.id = k.user_id ORDER BY k.id DESC`).all();
const revokeKey = (id, userId) => userId
  ? db.prepare('UPDATE api_keys SET revoked = 1 WHERE id = ? AND user_id = ?').run(id, userId)
  : db.prepare('UPDATE api_keys SET revoked = 1 WHERE id = ?').run(id);
const setKeyRate = (id, rate) => db.prepare('UPDATE api_keys SET rate_per_min = ? WHERE id = ?').run(rate, id);

// ---------- usage & stats ----------
const logUsage = ({ userId = null, keyId = null, source, promptChars = 0, replyChars = 0, ms = 0, ok = 1 }) =>
  db.prepare('INSERT INTO usage(user_id,key_id,source,prompt_chars,reply_chars,ms,ok,ts) VALUES(?,?,?,?,?,?,?,?)')
    .run(userId, keyId, source, promptChars, replyChars, ms, ok, now());
const recentUsage = (limit = 100) => db.prepare(`
  SELECT x.id,x.source,x.prompt_chars,x.reply_chars,x.ms,x.ok,x.ts,u.username
  FROM usage x LEFT JOIN users u ON u.id = x.user_id ORDER BY x.id DESC LIMIT ?`).all(limit);
function stats() {
  const one = (sql, ...a) => db.prepare(sql).get(...a).n;
  const day = now() - 24 * 3600 * 1000;
  return {
    users: one('SELECT COUNT(*) AS n FROM users'),
    chats: one('SELECT COUNT(*) AS n FROM chats'),
    messages: one('SELECT COUNT(*) AS n FROM messages'),
    active_keys: one('SELECT COUNT(*) AS n FROM api_keys WHERE revoked = 0'),
    requests_24h: one('SELECT COUNT(*) AS n FROM usage WHERE ts > ?', day),
    api_requests_24h: one("SELECT COUNT(*) AS n FROM usage WHERE ts > ? AND source = 'api'", day),
    errors_24h: one('SELECT COUNT(*) AS n FROM usage WHERE ts > ? AND ok = 0', day),
  };
}

module.exports = {
  db, sha256, verifyPassword,
  getSetting, setSetting, allSettings,
  createUser, getUserByName, getUserById, listUsers, setBanned, deleteUser,
  createSession, getSessionUser, deleteSession,
  createChat, listChats, getChat, renameChat, deleteChat, addMessage, getMessages,
  createKey, getKey, touchKey, listKeys, countActiveKeys, listAllKeys, revokeKey, setKeyRate,
  logUsage, recentUsage, stats,
};
