# Trox — Mesh 5

Self-hosted chat site + API + secret owner panel for your own LLM, **Mesh 5**.
Domain: `ai.trox.dpdns.org` · Port: `6969` · Storage: SQLite via `db.js`.

## 1. Run the model (Ollama)

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull qwen2.5:3b          # fits ~4GB RAM; use qwen2.5:7b with 8GB+
ollama create mesh5 -f Modelfile
ollama run mesh5 "who are you?" # should answer as Mesh 5
```

Ollama listens on `127.0.0.1:11434`. Do not expose that port.

## 2. Install Trox

```bash
sudo apt install -y nodejs npm build-essential python3   # Node 18+ required
cd trox
npm install
cp .env.example .env
nano .env        # set OWNER_PATH and OWNER_PASSWORD
node server.js
```

## 3. Keep it running

```bash
sudo npm i -g pm2
pm2 start server.js --name trox
pm2 save && pm2 startup
```

## 4. Cloudflare Tunnel → ai.trox.dpdns.org

```bash
cloudflared tunnel login
cloudflared tunnel create trox
cloudflared tunnel route dns trox ai.trox.dpdns.org
```

`~/.cloudflared/config.yml`:

```yaml
tunnel: trox
credentials-file: /root/.cloudflared/<TUNNEL-ID>.json
ingress:
  - hostname: ai.trox.dpdns.org
    service: http://localhost:6969
  - service: http_status:404
```

```bash
cloudflared service install
```

Note: `dpdns.org` is a free subdomain service. If it won't let you point DNS at a
Cloudflare tunnel, add the domain to Cloudflare as a zone first (change its nameservers),
or use a domain you fully control.

Firewall: allow only SSH. Ports 6969 and 11434 stay local.

## Using it

- **Website:** `https://ai.trox.dpdns.org` — sign up, chat, create API keys.
- **API:**
  ```bash
  curl https://ai.trox.dpdns.org/v1/chat \
    -H "Authorization: Bearer mesh5_..." \
    -H "Content-Type: application/json" \
    -d '{"messages":[{"role":"user","content":"Hello"}]}'
  ```
  Add `"stream": true` for server-sent events (`{"delta":"…"}`, ends with `[DONE]`).
- **Owner panel:** `https://ai.trox.dpdns.org/<OWNER_PATH>` — users, keys, rate limits,
  usage log, model name, system prompt, signups on/off. Login is rate-limited; sessions last 12h.

## Files

| File | Purpose |
|---|---|
| `db.js` | SQLite database: users, sessions, chats, messages, API keys, usage, settings |
| `server.js` | Express server: web auth, chat streaming, `/v1/chat` API, owner panel routes |
| `public/index.html` | Chat UI + API key manager |
| `views/owner.html` | Owner panel (served only at your secret path) |
| `Modelfile` | Brands the base model as Mesh 5 |
| `data/trox.db` | Created on first run — back this file up |

## Notes

- Passwords are scrypt-hashed; sessions and API keys are stored only as SHA-256 hashes.
- Back up `data/trox.db` regularly: `sqlite3 data/trox.db ".backup backup.db"`.
- CPU-only VPS means a few tokens/second. A small model (3B) is the right call.
